export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyDUapIzn9un-qy5qdf649EXp3Wdwo0Fxxo",
    authDomain: "ng-bio.firebaseapp.com",
    databaseURL: "https://ng-bio.firebaseio.com",
    projectId: "ng-bio",
    storageBucket: "",
    messagingSenderId: "393425171503"
  }
};
