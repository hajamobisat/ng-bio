import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mat-nav-bar',
  templateUrl: './mat-nav-bar.component.html',
  styleUrls: ['./mat-nav-bar.component.css']
})
export class MatNavBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
