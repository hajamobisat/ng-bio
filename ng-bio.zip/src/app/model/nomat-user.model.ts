export class NomatUser {
    id:string;
    email:string;
    isActive: boolean;
     roles:{ isUser: boolean, isAdmin: boolean};
}
